create
    definer = root@localhost procedure spUpdateLogin(IN vUser varchar(15), IN vDate datetime)
BEGIN
	UPDATE usuarios SET
	last_login = vDate
	where `user` = vUser;
END;

