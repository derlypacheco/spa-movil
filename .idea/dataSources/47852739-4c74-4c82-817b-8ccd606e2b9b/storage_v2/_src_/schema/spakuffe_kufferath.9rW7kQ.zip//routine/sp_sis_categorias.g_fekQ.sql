create
    definer = root@localhost procedure sp_sis_categorias()
BEGIN
SELECT
	sis_categorias.id_cat,
	sis_categorias.nombre_cat,
	sis_categorias.user_cat,
	sis_categorias.fecha_cat,
	sis_categorias.activo_cat
FROM
	sis_categorias
WHERE
	sis_categorias.activo_cat = '1'
	ORDER BY nombre_cat asc;
END;

