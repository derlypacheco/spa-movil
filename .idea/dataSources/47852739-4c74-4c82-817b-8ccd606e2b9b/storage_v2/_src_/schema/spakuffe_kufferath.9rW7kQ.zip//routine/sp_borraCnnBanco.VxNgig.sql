create
    definer = root@localhost procedure sp_borraCnnBanco(IN vID int, IN vUser varchar(15))
BEGIN
update bancos set bancos.activo_fban = 0, bancos.user_fban = vUser
where bancos.id_fban = vID;
END;

