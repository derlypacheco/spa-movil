create
    definer = root@localhost procedure spBorrarAlmacen(IN vFolio varchar(180), IN vUser varchar(15))
BEGIN
	UPDATE alm_almacenes SET
		alm_almacenes.activo_alm = '0',
		alm_almacenes.user_alm = vUser
	WHERE
		alm_almacenes.id_alm = vFolio;
END;

