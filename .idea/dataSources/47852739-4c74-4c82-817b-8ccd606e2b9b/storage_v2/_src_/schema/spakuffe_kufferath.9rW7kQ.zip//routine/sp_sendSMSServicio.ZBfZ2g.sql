create
    definer = root@localhost procedure sp_sendSMSServicio(IN vFolio varchar(200), IN vCliente char)
BEGIN
SELECT
	usuarios.nombre,
	usuarios.apellidos,
	usuarios.telefono
FROM
	servassig
	INNER JOIN servicios ON servassig.folio = servicios.folio
	INNER JOIN usuarios ON servassig.id_user = usuarios.idUser
WHERE
	servassig.folio = vFolio
	AND usuarios.cliente = vCliente;
END;

