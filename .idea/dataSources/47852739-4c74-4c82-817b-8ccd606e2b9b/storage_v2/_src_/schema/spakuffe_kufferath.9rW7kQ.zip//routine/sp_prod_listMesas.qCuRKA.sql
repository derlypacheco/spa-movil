create
    definer = root@localhost procedure sp_prod_listMesas()
BEGIN
	select * from prod_mesas where prod_mesas.activa_mesa = '1';
END;

