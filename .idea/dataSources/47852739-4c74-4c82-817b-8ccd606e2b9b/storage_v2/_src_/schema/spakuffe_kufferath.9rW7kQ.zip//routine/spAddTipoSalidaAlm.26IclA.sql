create
    definer = root@localhost procedure spAddTipoSalidaAlm(IN vTipos varchar(180), IN vFecha datetime, IN vUser varchar(15))
BEGIN
	INSERT INTO alm_tiposalidas (salida_tam, fecha_tam, user_tam)
	VALUES (vTipos, vFecha, vUser);
END;

