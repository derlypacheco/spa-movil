create
    definer = root@localhost procedure sp_prod_estadoMesa(IN vID int, IN vCode varchar(25))
BEGIN
	select estatus_detmesa from prod_mesa_detalle where prod_mesa_detalle.pos_detmesa = vCode and prod_mesa_detalle.id_prod_mesa = vID;
END;

