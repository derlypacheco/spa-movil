create
    definer = root@localhost procedure sp_tableros_listComent(IN vKey varchar(10))
BEGIN
SELECT
	ordenes_seg.fecha_orseg,
	ordenes_seg.coment_orseg,
	ordenes_seg.key_orseg,
	concat( usuarios.nombre, " ", usuarios.apellidos ) AS nombres,
	usuarios.foto
FROM
	ordenes_seg
	INNER JOIN usuarios ON ordenes_seg.user_orseg = usuarios.`user`
WHERE
	ordenes_seg.activo_orseg = '1' and
	ordenes_seg.key_orseg = vKey
	ORDER BY ordenes_seg.id_orseg;
END;

