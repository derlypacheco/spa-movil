create
    definer = root@localhost procedure cfs_add_trbl(IN ID_falla int, IN Cliente varchar(10), IN folio varchar(25),
                                                    IN destrbl longtext, IN IDtiporack int, IN HK varchar(20),
                                                    IN usuario varchar(30), IN version varchar(15), IN soft int)
BEGIN
INSERT INTO cfs_trbl
        (
        id_tipofalla,
        id_cliente,
        folio_trbl,
        desc_trbl,
        id_tiporack,
        hk_trbl,
        fecha_trbl,
        user_trbl,
				version_trbl,
				id_app
        )
      VALUES
        (
          ID_falla,
          Cliente,
          folio,
         destrbl,
         IDtiporack,
				 HK,
				 current_timestamp(),
          usuario,
					version,
					soft
        );
END;

