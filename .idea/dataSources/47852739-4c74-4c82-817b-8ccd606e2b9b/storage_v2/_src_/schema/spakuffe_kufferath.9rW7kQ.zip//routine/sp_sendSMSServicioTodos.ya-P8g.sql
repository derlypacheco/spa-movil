create
    definer = root@localhost procedure sp_sendSMSServicioTodos(IN vFolio varchar(200))
BEGIN
SELECT
	usuarios.nombre,
	usuarios.apellidos,
	usuarios.telefono
FROM
	servassig
	INNER JOIN servicios ON servassig.folio = servicios.folio
	INNER JOIN usuarios ON servassig.id_user = usuarios.idUser
WHERE
	servassig.folio = vFolio;
END;

