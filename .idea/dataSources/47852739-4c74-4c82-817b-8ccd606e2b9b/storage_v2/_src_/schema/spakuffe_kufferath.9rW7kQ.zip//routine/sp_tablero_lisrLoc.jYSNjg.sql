create
    definer = root@localhost procedure sp_tablero_lisrLoc()
BEGIN
	select * from locaciones where locaciones.activo_loc = '1' ORDER BY locaciones.locacion;
END;

