create
    definer = root@localhost procedure spListTipoSalidas()
BEGIN
	SELECT
alm_tiposalidas.id_salaml,
alm_tiposalidas.salida_tam,
alm_tiposalidas.fecha_tam,
alm_tiposalidas.activo_tam,
alm_tiposalidas.user_tam
FROM
alm_tiposalidas
WHERE
alm_tiposalidas.activo_tam = '1';
END;

