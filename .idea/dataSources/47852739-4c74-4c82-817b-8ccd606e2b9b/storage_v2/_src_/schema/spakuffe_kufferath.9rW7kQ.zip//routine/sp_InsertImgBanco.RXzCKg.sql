create
    definer = root@localhost procedure sp_InsertImgBanco(IN vName varchar(150), IN vFoto text, IN vFolio int,
                                                         IN vFecha date, IN vUser varchar(15))
BEGIN
	INSERT INTO bancos_rel (id_fban, namepic_relban, fecha_relban, user_relban, pic_relban)
	VALUES
	(vFolio, vName, vFecha, vUser, vFoto);
END;

