create
    definer = root@localhost procedure sp_prod_insertComent(IN vID int, IN vUser varchar(15), IN vComent text, IN vRuta text)
BEGIN
insert into prod_mesa_comit
(id_detmesa, user_comitMod, fecha_comitMod, coment_comitMod, file_comitMod)
VALUES
(vID, vUser, CURRENT_DATE, vComent, vRuta);
END;

