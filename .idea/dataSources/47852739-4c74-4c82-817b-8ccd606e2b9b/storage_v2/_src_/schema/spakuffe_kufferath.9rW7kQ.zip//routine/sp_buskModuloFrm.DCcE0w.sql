create
    definer = root@localhost procedure sp_buskModuloFrm(IN vNum varchar(25), IN vDisp int)
BEGIN
select * from disp_modulos
where
id_cliente_mod = vNum
and
disp_mod = vDisp;
END;

