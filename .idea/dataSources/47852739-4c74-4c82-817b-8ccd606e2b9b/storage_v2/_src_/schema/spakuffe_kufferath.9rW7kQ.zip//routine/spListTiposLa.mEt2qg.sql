create
    definer = root@localhost procedure spListTiposLa()
BEGIN
	SELECT * FROM alm_tipola 	WHERE activo_tla = '1';
END;

