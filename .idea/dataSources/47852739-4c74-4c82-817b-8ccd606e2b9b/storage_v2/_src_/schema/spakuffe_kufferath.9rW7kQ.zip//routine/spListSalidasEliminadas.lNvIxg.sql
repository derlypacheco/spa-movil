create
    definer = root@localhost procedure spListSalidasEliminadas()
BEGIN
	SELECT
alm_salidas.id_sal,
alm_salidas.fecha_sal,
alm_salidas.user_sal,
alm_salidas.folio_sal,
alm_salidas.activo_sal,
alm_salidas.tipo_sal,
alm_salidas.estatus_sal,
alm_salidas.solicito_sal,
concat(usuarios.nombre, ' ', usuarios.apellidos) AS elimino,
departamentos.departamento
FROM
alm_salidas
INNER JOIN usuarios ON alm_salidas.user_sal = usuarios.`user`
INNER JOIN departamentos ON alm_salidas.idDepartamento = departamentos.idDepartamento
WHERE
alm_salidas.activo_sal = '0';
END;

