create
    definer = root@localhost procedure sp_LoadDataInventario(IN vTotales int, IN vDisp int, IN vGlobal int)
BEGIN
UPDATE disp_relaciones SET
	disp_relaciones.stock_relacion = vTotales,
	disp_relaciones.disp_relacion = vDisp
WHERE
	disp_relaciones.id_relaciones = vGlobal;
END;

