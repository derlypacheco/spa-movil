create
    definer = root@localhost procedure spUserUno(IN nameUser varchar(10))
select * from usuarios WHERE `user` = nameUser;

