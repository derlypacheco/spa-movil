create
    definer = root@localhost procedure spListBancos()
BEGIN
SELECT
	bancos.id_fban,
	bancos.date_fban,
	bancos.name_fban,
	bancos.modulo_fban,
	bancos.user_fban,
	bancos.activo_fban,
	CONCAT( usuarios.nombre, " ", usuarios.apellidos ) AS nombre
FROM
	bancos
	INNER JOIN usuarios ON bancos.user_fban = usuarios.`user`
WHERE
	bancos.activo_fban = '1';
END;

