create
    definer = root@localhost procedure sp_AddCavidades(IN vStart varchar(10), IN vRand varchar(13),
                                                       IN vUser varchar(20), IN vLinea varchar(180), IN vDisp int)
BEGIN
	INSERT into disp_relaciones
	(cavidad_relacion ,key_relacion, user_relacion, linea_relacion, disp_relacion)
	VALUES
	(vStart, vRand, vUser, vLinea, vDisp);
END;

