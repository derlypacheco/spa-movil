create
    definer = root@localhost procedure sp_addModBanco(IN vDate datetime, IN vNameCnn varchar(150),
                                                      IN vModulo varchar(50), IN vUser varchar(15))
BEGIN
insert into bancos (
date_fban,
name_fban,
modulo_fban,
user_fban
) values (
vDate,
vNameCnn,
vModulo,
vUser
);
END;

