create
    definer = root@localhost procedure sp_sis_listarProductos()
BEGIN
	SELECT * FROM sis_productos WHERE sis_productos.activo_prod = '1';
END;

