create
    definer = root@localhost procedure spTipoSalAlmUno(IN vID int)
BEGIN
	SELECT
	alm_tiposalidas.salida_tam
	FROM alm_tiposalidas
	WHERE
	alm_tiposalidas.id_salaml = vID;
END;

