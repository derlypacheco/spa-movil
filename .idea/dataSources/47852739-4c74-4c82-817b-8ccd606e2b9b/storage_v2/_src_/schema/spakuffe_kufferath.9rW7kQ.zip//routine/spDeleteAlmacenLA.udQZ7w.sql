create
    definer = root@localhost procedure spDeleteAlmacenLA(IN vFolio int)
BEGIN
	update alm_inventario_cant set
	alm_inventario_cant.activo_lacant = '0'
	where alm_inventario_cant.id_inv_cant = vFolio;
END;

