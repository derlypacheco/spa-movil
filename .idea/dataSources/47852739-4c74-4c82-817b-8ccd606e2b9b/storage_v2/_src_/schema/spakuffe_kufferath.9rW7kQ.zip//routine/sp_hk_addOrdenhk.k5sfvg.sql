create
    definer = root@localhost procedure sp_hk_addOrdenhk(IN uuid varchar(40), IN norden varchar(15),
                                                        IN ordenCliente varchar(30), IN cliente int,
                                                        IN proyecto varchar(120), IN fechaent date, IN tipo int,
                                                        IN pais int, IN costo decimal(13), IN descrip text,
                                                        IN file text)
insert into hk_ordeneshk
(uuid_hk, work_orden_hk, cliente_orden_hk, cliente_id_hk, project_hk, fecha_hk, tipo_hk, costo_hk, desc_hk, file_hk, fecha_fin_hk, pais_hk)
values
(uuid, norden, ordenCliente, cliente, proyecto, CURRENT_TIMESTAMP, tipo, costo, descrip, file, fechaent, pais);

