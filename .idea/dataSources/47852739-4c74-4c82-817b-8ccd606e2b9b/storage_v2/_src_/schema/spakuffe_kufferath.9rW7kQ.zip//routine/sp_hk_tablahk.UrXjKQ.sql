create
    definer = root@localhost procedure sp_hk_tablahk()
BEGIN
select * from hk_ordeneshk where hk_ordeneshk.active_hk = '1';
END;

