create
    definer = root@localhost procedure sp_sis_Borra_Activity(IN vID int)
BEGIN
UPDATE sis_seguimiento set sis_seguimiento.activo_seg = '0' where sis_seguimiento.id_seg_prod = vID;
END;

