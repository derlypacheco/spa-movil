create
    definer = root@localhost procedure sp_hk_deleteCliente(IN vID int)
update hk_clientes set hk_clientes.active_clie = '0' where hk_clientes.id_ciente = vID;

