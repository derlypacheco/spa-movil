create
    definer = root@localhost procedure spVerSolicitudEntrada(IN vID int)
BEGIN
SELECT
alm_entradas.id_en,
alm_entradas.fecha_en,
alm_entradas.user_en,
alm_entradas.folio_en,
alm_entradas.activo_en,
alm_entradas.cfdi_en,
alm_entradas.desc_en,
concat(usuarios.nombre, ' ', usuarios.apellidos) as nombre
FROM
alm_entradas
INNER JOIN usuarios ON alm_entradas.user_en = usuarios.`user`
WHERE
alm_entradas.activo_en = '1' and
alm_entradas.id_en = vID;
END;

