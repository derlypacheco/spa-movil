create
    definer = root@localhost procedure sp_hk_listClientes()
SELECT
hk_clientes.id_ciente,
hk_clientes.cliente_clie,
hk_clientes.mail_clie,
hk_clientes.fecha_clie,
concat(usuarios.nombre, ' ', usuarios.apellidos) as nombre
FROM
hk_clientes
JOIN usuarios
ON hk_clientes.user_clie = usuarios.`user`
WHERE hk_clientes.active_clie = '1'
order by hk_clientes.cliente_clie ASC;

