create
    definer = root@localhost procedure UsuarioUno(IN nameUser varchar(10))
BEGIN
	select * from usuarios WHERE `user` = nameUser;

END;

