create
    definer = root@localhost procedure spDeleteSalAlm(IN vID varchar(150), IN vUser varchar(15))
BEGIN
UPDATE alm_salidas SET
alm_salidas.activo_sal = '0',
alm_salidas.user_sal = vUser
WHERE
alm_salidas.folio_sal = vID;
END;

