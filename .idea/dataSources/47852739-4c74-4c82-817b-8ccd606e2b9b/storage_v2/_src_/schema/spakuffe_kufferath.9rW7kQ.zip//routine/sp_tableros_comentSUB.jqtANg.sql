create
    definer = root@localhost procedure sp_tableros_comentSUB(IN vUser varchar(15), IN vComent text, IN vFile text,
                                                             IN vKey varchar(8))
BEGIN
	INSERT INTO ordenes_seg
	(user_orseg, fecha_orseg, coment_orseg, file_orseg, key_orseg)
	VALUES
  (vUser, CURRENT_TIMESTAMP, vComent, vFile, vKey);
END;

