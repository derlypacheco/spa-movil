create
    definer = root@localhost procedure cfs_add_tiporack(IN rack varchar(100), IN des_rack longtext, IN usuario varchar(30))
BEGIN
insert into cfs_tiporack (tiporack, desc_rack, user_rack, fecha_rack) values (rack, des_rack, usuario, current_timestamp());
END;

