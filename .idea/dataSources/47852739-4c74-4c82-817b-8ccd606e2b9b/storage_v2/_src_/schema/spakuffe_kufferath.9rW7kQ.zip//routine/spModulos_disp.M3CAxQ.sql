create
    definer = root@localhost procedure spModulos_disp(IN vModulo varchar(50))
BEGIN
	SELECT
	disp_modulos.id_modulo as ID,
	disp_modulos.id_cliente_mod as Parte,
	disp_modulos.noPart_mod as NumeroM,
	disp_modulos.cant_cav_mod as Cavidades,
	disp_modulos.cant_det_mod as Detecciones,
	disp_relaciones.id_la_disp as ID_LA,
	disp_relaciones.id_relaciones as Relacion
FROM
	disp_modulos
	INNER JOIN disp_relaciones ON disp_relaciones.id_modulo = disp_modulos.id_modulo
WHERE
	disp_relaciones.id_la_disp = vModulo
GROUP BY
	disp_relaciones.id_modulo;
END;

