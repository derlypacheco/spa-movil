create
    definer = root@localhost procedure sp_BuscarDispensar(IN vLinea varchar(30), IN vMesa varchar(100),
                                                          IN vConector varchar(30), IN vCavidad varchar(20))
BEGIN
SELECT
	disp_inventariola.prov_la_disp,
	disp_relaciones.cavidad_relacion,
	disp_modulos.id_cliente_mod,
	disp_inventariola.numPart_Prov_la_disp,
	disp_inventariola.numPart_Cliente_la_disp,
	disp_inventariola.existencia_la_disp,
	disp_inventariola.foto_la_disp,
	disp_inventariola.llave_la_disp,
	disp_inventariola.tipo_la_disp,
	disp_inventariola.marcaProv_la_disp,
	disp_relaciones.coorx_relacion,
	disp_relaciones.coory_relacion,
	disp_relaciones.pinBlock_relacion,
	disp_relaciones.linea_relacion,
	disp_relaciones.id_relaciones,
	disp_relaciones.min_stock_relacion,
	disp_relaciones.max_stock_relacion,
	disp_relaciones.stock_relacion
FROM
	disp_inventariola
	INNER JOIN disp_relaciones ON disp_inventariola.id_la_disp = disp_relaciones.id_la_disp
	INNER JOIN disp_modulos ON disp_relaciones.id_modulo = disp_modulos.id_modulo
WHERE
	id_cliente_mod = vConector
	AND cavidad_relacion = vCavidad;
END;

