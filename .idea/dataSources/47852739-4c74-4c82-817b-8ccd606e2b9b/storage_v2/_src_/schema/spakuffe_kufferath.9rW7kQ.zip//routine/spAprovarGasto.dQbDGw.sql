create
    definer = root@localhost procedure spAprovarGasto(IN vFolio varchar(200), IN vApro char)
BEGIN
	UPDATE gastos SET
	gastos.activo_gasto = vApro
	WHERE gastos.folioFiscal = vFolio COLLATE utf8_unicode_ci;
END;

