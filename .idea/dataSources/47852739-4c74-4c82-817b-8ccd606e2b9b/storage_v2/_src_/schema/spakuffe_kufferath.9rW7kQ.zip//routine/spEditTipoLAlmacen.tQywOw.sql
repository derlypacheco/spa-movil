create
    definer = root@localhost procedure spEditTipoLAlmacen(IN vTipoAlmacen varchar(150), IN vUser varchar(15), IN vID int)
BEGIN
	UPDATE alm_tipola SET
		alm_tipola.tipo_tla = vTipoAlmacen,
		alm_tipola.user_tla = vUser
	WHERE
		alm_tipola.id_tla = vID;
END;

