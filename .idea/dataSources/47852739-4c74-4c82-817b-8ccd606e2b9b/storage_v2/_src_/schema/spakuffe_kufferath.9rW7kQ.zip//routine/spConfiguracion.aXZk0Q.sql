create
    definer = root@localhost procedure spConfiguracion()
BEGIN
	SELECT * FROM configuracion;
END;

