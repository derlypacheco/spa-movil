create
    definer = root@localhost procedure sp_buskFMDisp(IN vFM varchar(150))
BEGIN
	select * from disp_inventariola
	where disp_inventariola.numPart_Prov_la_disp = vFM;
END;

