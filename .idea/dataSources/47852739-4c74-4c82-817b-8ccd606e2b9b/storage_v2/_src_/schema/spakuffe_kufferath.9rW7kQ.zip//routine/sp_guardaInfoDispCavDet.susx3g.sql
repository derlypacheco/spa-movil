create
    definer = root@localhost procedure sp_guardaInfoDispCavDet(IN vCavidad varchar(10), IN vUser varchar(15),
                                                               IN vCoorX varchar(3), IN vCoorY varchar(3),
                                                               IN vPinLook char(2), IN vContador char(3),
                                                               IN vIDmodulo int, IN vMax int, IN vMin int, IN vIDLA int,
                                                               IN vModuloReal int)
BEGIN
	UPDATE disp_relaciones SET
	cavidad_relacion = vCavidad,
	user_relacion = vUser,
	coorx_relacion = vCoorX,
	coory_relacion = vCoorY,
	pinBlock_relacion = vPinLook,
	pinContador_relacion = vContador,
	min_stock_relacion = vMin,
	max_stock_relacion = vMax,
	id_la_disp = vIDLA,
	id_modulo = vIDmodulo
	WHERE
	id_relaciones = vModuloReal;
END;

