create
    definer = root@localhost procedure spVistaLA(IN vLA varchar(150))
BEGIN
	SELECT
alm_inventario.id_inv,
alm_inventario.name_la,
alm_inventario.desc_la,
alm_inventario.clave_alm,
alm_inventario.fecha_la,
alm_inventario.user_la,
alm_inventario.activo_la,
alm_inventario.clave_sat_la,
alm_inventario.id_tla,
alm_inventario.barcode_la,
alm_inventario.locacion_la,
alm_inventario.campo1_la,
alm_inventario.campo2_la,
alm_inventario_cant.id_inv_cant,
alm_inventario_cant.name_lacant,
alm_inventario_cant.fecha_lacant,
alm_inventario_cant.user_lacant,
alm_inventario_cant.activo_lacant,
alm_inventario_cant.exist_lacant,
alm_inventario_cant.min_lacant,
alm_inventario_cant.max_lacant,
alm_inventario_cant.costo_lacant,
alm_tipola.id_tla,
alm_tipola.tipo_tla,
alm_tipola.activo_tla,
alm_tipola.user_tla,
alm_tipola.fecha_tla,
alm_tipola.desc_tla,
alm_almacenes.id_alm,
alm_almacenes.clave_alm,
alm_almacenes.almacen_alm,
alm_almacenes.fecha_alm,
alm_almacenes.activo_alm,
alm_almacenes.user_alm,
alm_almacenes.desc_alm,
CONCAT(usuarios.nombre, ' ', usuarios.apellidos) as nombre
FROM
alm_inventario
INNER JOIN alm_inventario_cant ON alm_inventario.name_la = alm_inventario_cant.name_lacant
INNER JOIN alm_tipola ON alm_inventario.id_tla = alm_tipola.id_tla
INNER JOIN alm_almacenes ON alm_inventario.clave_alm = alm_almacenes.clave_alm
INNER JOIN usuarios ON alm_inventario.user_la = usuarios.`user`
WHERE
alm_inventario.activo_la = '1' and alm_inventario.name_la = vLA;
END;

