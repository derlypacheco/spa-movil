create
    definer = root@localhost procedure spComprobaciones()
BEGIN
	SELECT * from comprovaciones;

END;

