create
    definer = root@localhost procedure spUsuarioUno(IN nameUser varchar(10))
BEGIN
	select
	CONCAT(nombre, ' ', apellidos) as nombre
	from usuarios WHERE `user` = nameUser;

END;

