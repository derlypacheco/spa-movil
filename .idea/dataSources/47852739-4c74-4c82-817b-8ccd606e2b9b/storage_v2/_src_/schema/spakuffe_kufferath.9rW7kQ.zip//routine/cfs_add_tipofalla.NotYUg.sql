create
    definer = root@localhost procedure cfs_add_tipofalla(IN falla varchar(150), IN des_falla longtext, IN usuario varchar(30))
BEGIN
INSERT INTO cfs_tipofalla 
(tipofalla, desc_falla, user_falla, fecha_falla) 
VALUES 
(falla, des_falla, usuario, current_timestamp());
END;

