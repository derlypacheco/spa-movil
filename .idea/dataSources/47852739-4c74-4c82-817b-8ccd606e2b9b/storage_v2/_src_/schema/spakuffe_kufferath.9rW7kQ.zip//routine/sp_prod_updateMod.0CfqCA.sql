create
    definer = root@localhost procedure sp_prod_updateMod(IN vID int, IN vValue char)
BEGIN
	update prod_mesa_detalle set prod_mesa_detalle.estatus_detmesa = vValue where prod_mesa_detalle.id_detmesa = vID;
END;

