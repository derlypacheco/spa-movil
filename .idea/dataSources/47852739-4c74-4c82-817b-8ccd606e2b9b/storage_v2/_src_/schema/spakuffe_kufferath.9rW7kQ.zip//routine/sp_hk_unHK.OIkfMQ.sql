create
    definer = root@localhost procedure sp_hk_unHK(IN vFolio varchar(100))
SELECT
hk_ordeneshk.id_ordenhk,
hk_ordeneshk.uuid_hk,
hk_ordeneshk.work_orden_hk,
hk_ordeneshk.cliente_orden_hk,
hk_ordeneshk.project_hk,
hk_ordeneshk.fecha_hk,
hk_ordeneshk.costo_hk,
hk_ordeneshk.desc_hk,
hk_ordeneshk.file_hk,
hk_ordeneshk.fecha_fin_hk,
hk_clientes.cliente_clie,
hk_paises.pais_ps,
hk_paises.moneda_ps,
hk_tiposhk.tipo_th
FROM
hk_ordeneshk
JOIN hk_clientes
ON hk_ordeneshk.cliente_id_hk = hk_clientes.id_ciente
JOIN hk_paises
ON hk_ordeneshk.pais_hk = hk_paises.id_paishk
JOIN hk_tiposhk
ON hk_ordeneshk.tipo_hk = hk_tiposhk.id_tipohk
WHERE
hk_ordeneshk.uuid_hk = vFolio collate utf8_general_ci;

