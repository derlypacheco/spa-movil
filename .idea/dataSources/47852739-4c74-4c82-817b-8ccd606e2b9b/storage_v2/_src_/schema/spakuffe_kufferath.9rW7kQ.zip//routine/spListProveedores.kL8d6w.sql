create
    definer = root@localhost procedure spListProveedores()
BEGIN
    SELECT * FROM alm_provedores WHERE alm_provedores.activo_prov = '1';
end;

