create
    definer = root@localhost procedure spAddEntradaDeAlmacen(IN vLA varchar(150), IN vAlmacen varchar(15), IN vMin int,
                                                             IN vMax int, IN vStock int, IN vCosto int,
                                                             IN vUser varchar(15), IN vFecha datetime)
BEGIN
	INSERT INTO alm_inventario_cant
		(name_lacant, fecha_lacant, user_lacant, exist_lacant, min_lacant, max_lacant, costo_lacant, almacen_lacant)
			VALUES
		(vLA, vFecha, vUser, vStock, vMin, vMax, vCosto, vAlmacen);
END;

