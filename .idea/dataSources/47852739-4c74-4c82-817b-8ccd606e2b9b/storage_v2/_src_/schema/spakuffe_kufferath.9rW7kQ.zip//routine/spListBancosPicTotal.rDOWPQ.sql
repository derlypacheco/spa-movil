create
    definer = root@localhost procedure spListBancosPicTotal(IN vID int)
BEGIN
SELECT count(*) AS total FROM bancos_rel WHERE id_fban = vID;
END;

