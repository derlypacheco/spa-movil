create
    definer = root@localhost procedure spListRelSalidasUno(IN vFolio varchar(50))
BEGIN
	SELECT
alm_relsalidas.id_rsal,
alm_relsalidas.folio_rsal,
alm_relsalidas.fecha_rsal,
alm_relsalidas.user_rsal,
alm_relsalidas.la_rsal,
alm_relsalidas.cant_rsal,
alm_relsalidas.costo_rsal,
alm_relsalidas.total_sal,
alm_relsalidas.activo_sal,
alm_relsalidas.solicito_sal,
concat(usuarios.nombre, ' ', usuarios.apellidos) as nombre
FROM
alm_relsalidas
INNER JOIN usuarios ON alm_relsalidas.user_rsal = usuarios.`user`
WHERE
alm_relsalidas.activo_sal = '1' and
alm_relsalidas.folio_rsal = vFolio;
END;

