create
    definer = root@localhost procedure sp_user_addCargo(IN vCargo varchar(100), IN vUser varchar(15),
                                                        IN vPlanta varchar(80))
BEGIN
	insert into cargos
	(cargo, user, fecha_carg, clave_planta)
	values
	(vCargo, vUser, CURRENT_TIMESTAMP, vPlanta);
END;

