create
    definer = root@localhost procedure spLoginCript(IN txtUser varchar(20), IN txtPass varchar(100))
BEGIN
SELECT
	usuarios.nombre,
	usuarios.apellidos,
	usuarios.correo,
	usuarios.telefono,
	usuarios.mail_jefe,
	usuarios.empresa,
	usuarios.idUser,
	usuarios.cliente,
	usuarios.`user`,
	usuarios.foto,
	usuarios.departamento,
	permisos.Permiso,
	permisos.crear_servicio
FROM
	usuarios
	INNER JOIN permisos ON usuarios.id_permiso = permisos.id_permiso
WHERE
	`user` = txtUser
	AND `password` = SHA1( MD5( txtPass ) )
	AND activo = '1';
END;

