create
    definer = root@localhost procedure spAddEntAlm(IN vFecha datetime, IN vUser varchar(15), IN vProveedor int,
                                                   IN vSucursal int, IN vFolio varchar(18))
BEGIN
INSERT INTO
	alm_entradas (
	fecha_en,
	user_en,
	proveedor_id,
	sucursal_en,
	folio_en
) VALUES (
	vFecha,
	vUser,
	vProveedor,
	vSucursal,
	vFolio
);
END;

