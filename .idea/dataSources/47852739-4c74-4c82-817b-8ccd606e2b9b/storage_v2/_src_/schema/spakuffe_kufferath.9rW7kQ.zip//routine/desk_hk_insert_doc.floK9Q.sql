create
    definer = root@localhost procedure desk_hk_insert_doc(IN title varchar(180), IN ruta longtext, IN users varchar(25),
                                                          IN folio varchar(15))
BEGIN
insert into hk_docs_conectores (title_doc, file_doc, date_doc, user_doc, folio_doc) values (title, ruta, current_timestamp(), users, folio);
END;

