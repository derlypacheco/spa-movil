create
    definer = root@localhost procedure sp_insertHKorden(IN vLocation int, IN vPorcentaje decimal(3), IN vStat text,
                                                        IN vDesc text, IN vUser varchar(15), IN vID int)
BEGIN
	UPDATE ordenes SET
	ordenes.id_locacion = vLocation,
	ordenes.porcentaje = vPorcentaje,
	ordenes.`status` = vStat,
	ordenes.descripcion = vDesc,
	ordenes.user_cap = vUser
	WHERE
		ordenes.id_orden = vID;
END;

