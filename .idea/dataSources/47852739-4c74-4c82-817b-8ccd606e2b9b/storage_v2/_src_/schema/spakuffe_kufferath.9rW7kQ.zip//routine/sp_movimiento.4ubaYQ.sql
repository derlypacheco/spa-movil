create
    definer = root@localhost procedure sp_movimiento(IN vUser varchar(15), IN vAccion varchar(200), IN vModulo text,
                                                     IN vIP varchar(50))
BEGIN
insert into movimientos (
fecha_mov,
user_mov,
accion_mov,
modulo_mov,
ip_mov
)
VALUES
(
now(),
vUser,
vAccion,
vModulo,
vIP
);
END;

