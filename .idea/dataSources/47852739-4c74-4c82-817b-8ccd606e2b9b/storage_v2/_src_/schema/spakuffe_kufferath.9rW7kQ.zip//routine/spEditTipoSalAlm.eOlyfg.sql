create
    definer = root@localhost procedure spEditTipoSalAlm(IN vSalida varchar(150), IN vUser varchar(15), IN vID int)
BEGIN
	UPDATE alm_tiposalidas set
	alm_tiposalidas.salida_tam = vSalida,
	alm_tiposalidas.user_tam = vUser
	WHERE
	alm_tiposalidas.id_salaml = vID;
END;

