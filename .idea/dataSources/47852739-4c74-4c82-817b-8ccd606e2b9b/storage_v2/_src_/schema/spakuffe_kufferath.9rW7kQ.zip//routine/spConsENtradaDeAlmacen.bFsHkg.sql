create
    definer = root@localhost procedure spConsENtradaDeAlmacen(IN vLA varchar(50), IN vAlmacen varchar(50))
BEGIN
	SELECT COUNT(name_lacant) as total from alm_inventario_cant where name_lacant = vLA and almacen_lacant = vAlmacen;
END;

