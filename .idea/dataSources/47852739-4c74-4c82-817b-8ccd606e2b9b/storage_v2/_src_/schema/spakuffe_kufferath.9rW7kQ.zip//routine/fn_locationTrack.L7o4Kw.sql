create
    definer = root@localhost function fn_locationTrack(departamento int(1)) returns varchar(80)
BEGIN

declare depto varchar(120);
case departamento
	when '1' then set depto = 'rel_vent';
    when '2' then set depto = 'rel_dise';
    when '3' then set depto = 'rel_cam';
    when '4' then set depto = 'rel_cnc';
    when '5' then set depto = 'rel_alm';
    when '6' then set depto = 'rel_ensa';
    when '7' then set depto = 'rel_banc';
    when '8' then set depto = 'rel_cal';
    when '9' then set depto = 'rel_emp';
end case;

RETURN depto;
END;

