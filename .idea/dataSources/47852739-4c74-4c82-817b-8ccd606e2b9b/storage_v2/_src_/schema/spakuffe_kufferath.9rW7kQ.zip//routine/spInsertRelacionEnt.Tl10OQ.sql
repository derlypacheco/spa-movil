create
    definer = root@localhost procedure spInsertRelacionEnt(IN vFolio varchar(10), IN vFecha datetime,
                                                           IN vUser varchar(15), IN vLA varchar(15),
                                                           IN vCant decimal(10, 2), IN vCosto decimal(10, 2),
                                                           IN vTotal decimal(10, 2))
BEGIN
    INSERT INTO alm_relentradas
    (folio_en, fecha_rent, user_rent, la_rent, cant_rent, costo_rent, total_rent)
    VALUES
    (vFolio, vFecha, vUser, vLA, vCant, vCosto, vTotal);
END;

