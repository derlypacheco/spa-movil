create
    definer = root@localhost procedure kf_sis_verpedido(IN ID int)
BEGIN
  
	select * from sis_pedidos where activa_ped = '1' and id_pedido = ID;

END;

