create
    definer = root@localhost procedure sp_sis_deleteCat(IN vID int)
BEGIN
update sis_categorias set
sis_categorias.activo_cat = '0'
WHERE
sis_categorias.id_cat = vID;
END;

