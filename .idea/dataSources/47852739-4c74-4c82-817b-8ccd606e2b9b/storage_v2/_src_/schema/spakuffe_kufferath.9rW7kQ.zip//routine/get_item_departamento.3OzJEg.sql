create
    definer = root@localhost function get_item_departamento(departamento varchar(80)) returns varchar(80)
BEGIN
declare item varchar(80);

case departamento 
	when 'Ventas' then set item = 'rel_vent';
    when 'Diseno' then set item = 'rel_dise';
    when 'CAM' then set item = 'rel_cam';
    when 'CNC' then set item = 'rel_cnc';
    when 'Almacen' then set item = 'rel_alm';
    when 'Ensamble' then set item = 'rel_ensa';
    when 'Bancos' then set item = 'rel_banc';
    when 'Calidad' then set item = 'rel_cal';
    when 'Empaque' then set item = 'rel_emp';
end case;

RETURN item;
END;

