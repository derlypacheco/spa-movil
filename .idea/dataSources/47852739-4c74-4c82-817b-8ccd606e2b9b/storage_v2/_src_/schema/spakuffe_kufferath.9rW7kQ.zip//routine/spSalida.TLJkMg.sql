create
    definer = root@localhost procedure spSalida(IN vid varchar(150))
BEGIN
	SELECT
alm_salidas.id_sal,
alm_salidas.fecha_sal,
alm_salidas.user_sal,
alm_salidas.folio_sal,
alm_salidas.activo_sal,
alm_salidas.tipo_sal,
alm_salidas.idDepartamento,
alm_salidas.estatus_sal
FROM
alm_salidas
WHERE
alm_salidas.folio_sal = vid;
END;

