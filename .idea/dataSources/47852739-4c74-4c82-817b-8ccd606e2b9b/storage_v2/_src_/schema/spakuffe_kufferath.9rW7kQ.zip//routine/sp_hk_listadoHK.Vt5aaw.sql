create
    definer = root@localhost procedure sp_hk_listadoHK()
BEGIN
SELECT
	ordenes.id_orden AS ID,
	ordenes.fecha_cap AS FECHA,
	CASE ordenes.`status` WHEN '1' THEN 'PROCESO'
	WHEN '2' THEN 'PRIORIDAD'
	WHEN '3' THEN 'URGENTE'
	WHEN '4' THEN 'COMPLETA'
ELSE '' end as ESTATUS,
	ordenes.orden AS ORDEN,
	ordenes.descripcion AS DESCRIPCION,
	locaciones.locacion  COLLATE utf8_unicode_ci AS LOCACION,
	CONCAT( usuarios.nombre, " ", usuarios.apellidos ) AS CREO
FROM
	ordenes
	INNER JOIN locaciones ON ordenes.id_locacion = locaciones.id_locacion
	INNER JOIN usuarios ON ordenes.user_cap = usuarios.`user`
ORDER BY id_orden;

END;

