create
    definer = root@localhost procedure sp_disp_guardaCavDet(IN vNumero varchar(10), IN vUser varchar(15),
                                                            IN vCartucho varchar(10), IN vCandado char(3),
                                                            IN vContador char(3), IN vIdModulo int, IN vMax int,
                                                            IN vMin int, IN IDLA int, IN IDModRelacion int)
BEGIN
	UPDATE disp_relaciones SET
	cavidad_relacion = vNumero,
	user_relacion = vUser,
	pinBlock_relacion = vCandado,
	pinContador_relacion = vContador,
	min_stock_relacion = vMin,
	max_stock_relacion = vMax,
	id_la_disp = IDLA,
	id_modulo = vIDmodulo,
	Cartucho_relacion = vCartucho
	WHERE
	id_relaciones = IDModRelacion;
END;

