create
    definer = root@localhost procedure sp_UpdateUserDisp(IN vNombre varchar(150), IN vPass varchar(150), IN vID int)
BEGIN
	UPDATE disp_usuarios SET
		disp_usuarios.nombre_user = vNombre,
		disp_usuarios.clave_user = vPass
	WHERE
		disp_usuarios.id_user = vID;
END;

