create
    definer = root@localhost procedure sp_AddLineaPlanta(IN vLinea varchar(150), IN vDispensador varchar(20))
BEGIN
	INSERT into disp_Lineas (linea_lndisp, dispendador_linea) values (vLinea, vDispensador);
END;

