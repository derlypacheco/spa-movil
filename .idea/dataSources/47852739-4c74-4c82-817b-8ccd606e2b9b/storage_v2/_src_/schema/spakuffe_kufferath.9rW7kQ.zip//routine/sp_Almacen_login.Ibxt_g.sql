create
    definer = root@localhost procedure sp_Almacen_login(IN QR text)
SELECT usuarios.`user` FROM usuarios
WHERE
usuarios.activo = '1'
AND
 UPPER(SHA1(MD5(usuarios.`user`))) = QR;

