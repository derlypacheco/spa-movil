create
    definer = root@localhost procedure cfs_delete_tiporack(IN ID int)
BEGIN
update cfs_tiporack set activo_rack = '0' where id_tiporack = ID;
END;

