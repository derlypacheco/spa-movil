create
    definer = root@localhost procedure sp_sis_Activity(IN vFolio varchar(20))
BEGIN
SELECT
	usuarios.foto,
	concat( usuarios.nombre, " ", usuarios.apellidos ) AS nombre,
	sis_seguimiento.fecha_seg,
	sis_seguimiento.coment_seg,
	sis_seguimiento.file_seg,
	sis_seguimiento.id_seg_prod
FROM
	sis_seguimiento
	INNER JOIN usuarios ON sis_seguimiento.user_seg = usuarios.`user`
WHERE
	sis_seguimiento.folio_seg = vFolio AND sis_seguimiento.activo_seg = '1';
END;

