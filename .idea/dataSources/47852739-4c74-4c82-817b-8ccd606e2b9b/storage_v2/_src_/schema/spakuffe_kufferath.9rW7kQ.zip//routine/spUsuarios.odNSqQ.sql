create
    definer = root@localhost procedure spUsuarios()
BEGIN
	SELECT * FROM usuarios WHERE activo = '1';

END;

