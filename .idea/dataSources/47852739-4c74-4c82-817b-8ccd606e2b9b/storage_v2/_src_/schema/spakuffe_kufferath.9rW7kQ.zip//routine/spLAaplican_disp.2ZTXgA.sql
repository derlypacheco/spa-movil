create
    definer = root@localhost procedure spLAaplican_disp(IN vLA varchar(25))
BEGIN
SELECT
	disp_relaciones.cavidad_relacion AS Cavidad,
	disp_inventariola.numPart_Prov_la_disp AS Numero
FROM
	disp_relaciones
	INNER JOIN disp_modulos ON disp_modulos.id_modulo = disp_relaciones.id_modulo
	INNER JOIN disp_inventariola ON disp_relaciones.id_la_disp = disp_inventariola.id_la_disp
WHERE
	disp_relaciones.id_la_disp = vLA;
END;

