create
    definer = root@localhost procedure spAlmacenesUno(IN vFolio int)
BEGIN
	SELECT
		alm_almacenes.desc_alm,
		alm_almacenes.almacen_alm,
		alm_almacenes.user_alm,
		alm_almacenes.fecha_alm,
		alm_almacenes.clave_alm,
		alm_almacenes.activo_alm,
		alm_almacenes.id_alm
	FROM alm_almacenes
	WHERE
	alm_almacenes.id_alm = vFolio and alm_almacenes.activo_alm = '1';
END;

