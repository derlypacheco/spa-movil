create
    definer = root@localhost procedure sp_resultCavDet(IN vCavDet int, IN vIdDisp int)
BEGIN
	select * from disp_relaciones
	where id_relaciones =  vCavDet
	and disp_relacion = vIdDisp;
END;

