create
    definer = root@localhost procedure spInsertLA(IN vLA varchar(20), IN vAlmacen varchar(20), IN vDesc varchar(220),
                                                  IN vUser varchar(15), IN vfecha datetime)
BEGIN
		INSERT INTO alm_inventario
	(name_la, id_tla, desc_la, user_la, fecha_la)
		VALUES
	(vLA, vAlmacen, vDesc, vUser, vFecha);
END;

