create
    definer = root@localhost procedure sp_listTableManuales(IN vActivo char)
BEGIN
SELECT
	disp_manuales.id_table as ID,
	disp_manuales.fecha_disp as Fecha,
	disp_manuales.title_disp as Nombre,
	disp_manuales.user_disp as Publico
FROM
	disp_manuales
WHERE
	disp_manuales.activo_disp = vActivo;
END;

