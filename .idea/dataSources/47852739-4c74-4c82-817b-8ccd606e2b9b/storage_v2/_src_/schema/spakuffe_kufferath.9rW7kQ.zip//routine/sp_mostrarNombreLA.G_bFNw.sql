create
    definer = root@localhost procedure sp_mostrarNombreLA(IN vID int)
BEGIN
select
numPart_Prov_la_disp as FMproveedor,
id_la_disp
from disp_inventariola
WHERE disp_inventariola.id_la_disp = vID;
END;

