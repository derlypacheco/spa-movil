create
    definer = root@localhost procedure cfs_add_coment_reporte(IN USUARIO varchar(30), IN CONT longtext,
                                                              IN FOLIO varchar(25), IN FILE longtext)
BEGIN
insert into cfs_seguimiento
 (
 fecha_seg,
 user_seg,
 cont_seg, 
 folio_seg,
 archivo_seg
 ) 
 values 
 (
 current_timestamp(),
 USUARIO,
 CONT,
 FOLIO,
 FILE
 );
END;

