create
    definer = root@localhost procedure spDelModuloCliente(IN vDelModulo varchar(50))
BEGIN
	UPDATE modules set
	modules.activo_mod = '0'
	WHERE
	modules.num_mod = vDelModulo COLLATE utf8_general_ci;
END;

