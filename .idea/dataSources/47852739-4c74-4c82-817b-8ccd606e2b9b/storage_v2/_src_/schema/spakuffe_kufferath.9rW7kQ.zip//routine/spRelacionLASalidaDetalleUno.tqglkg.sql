create
    definer = root@localhost procedure spRelacionLASalidaDetalleUno(IN vLA varchar(30))
BEGIN
	SELECT
alm_relsalidas.id_rsal,
alm_relsalidas.folio_rsal,
alm_relsalidas.fecha_rsal,
alm_relsalidas.user_rsal,
alm_relsalidas.la_rsal,
alm_relsalidas.cant_rsal,
alm_relsalidas.costo_rsal,
alm_relsalidas.total_sal,
alm_relsalidas.activo_sal,
alm_relsalidas.solicito_sal,
alm_inventario.desc_la,
alm_inventario.clave_sat_la,
alm_tipola.tipo_tla,
alm_almacenes.almacen_alm
	FROM
alm_relsalidas
	INNER JOIN alm_inventario ON alm_relsalidas.la_rsal = alm_inventario.name_la
	INNER JOIN alm_tipola ON alm_inventario.id_tla = alm_tipola.id_tla
	INNER JOIN alm_almacenes ON alm_inventario.clave_alm = alm_almacenes.clave_alm
	WHERE
alm_relsalidas.la_rsal = vLA;
END;

