create
    definer = root@localhost procedure sp_pedidos_ListarPed(IN vUser varchar(20))
BEGIN
SELECT
	sis_pedidos.id_pedido,
	sis_pedidos.folio_ped,
	sis_pedidos.fecha_ped,
	sis_pedidos.usuario_ped,
	sis_pedidos.estatus_ped,
	sis_pedidos.entrega_ped,
	sis_pedidos.activa_ped,
	concat( usuarios.nombre, " ", usuarios.apellidos ) AS creo
FROM
	sis_pedidos
	INNER JOIN usuarios ON sis_pedidos.usuario_ped = usuarios.`user`
	WHERE
	sis_pedidos.activa_ped = '1' and sis_pedidos.usuario_ped = vUser
ORDER BY
	sis_pedidos.id_pedido desc;
END;

