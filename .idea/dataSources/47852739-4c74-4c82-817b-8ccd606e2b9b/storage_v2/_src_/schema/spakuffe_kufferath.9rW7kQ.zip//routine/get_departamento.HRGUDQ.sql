create
    definer = root@localhost function get_departamento(departamento int(1)) returns varchar(80)
BEGIN
declare dpto varchar(80);

case departamento
	when '1' then set dpto = 'Ventas';
    when '2' then set dpto = 'Diseno';
    when '3' then set dpto = 'CAM';
    when '4' then set dpto = 'CNC';
    when '5' then set dpto = 'Almacen';
    when '6' then set dpto = 'Ensamble';
    when '7' then set dpto = 'Bancos';
    when '8' then set dpto = 'Calidad';
    when '9' then set dpto = 'Empaque';
end case;

RETURN dpto;
END;

