create
    definer = root@localhost procedure sp_ConsultaDispensador(IN vSerie varchar(180))
BEGIN
SELECT
	disp_dispensador.id_disp,
	disp_dispensador.serie_disp,
	disp_dispensador.hk_disp,
	disp_dispensador.ubicacion_disp,
	disp_dispensador.cliente_disp,
	disp_dispensador.planta_disp,
	disp_dispensador.activo_disp ,
	disp_dispensador.cartucho_disp
FROM
	disp_dispensador
WHERE
	serie_disp = vSerie
	AND
	activo_disp ='1';
END;

