create
    definer = root@localhost procedure sp_DelSerAdmin(IN vFolio varchar(50))
BEGIN
	#Routine body goes here...  activo_servicio
update servicios set activo_servicio = '0' where servicios.folio = vFolio;
END;

