create
    definer = root@localhost procedure sp_ComparaPermiso(IN vHuella int)
BEGIN
select * from disp_usuarios where huella_user = vHuella;
END;

