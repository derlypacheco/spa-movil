create
    definer = root@localhost procedure sp_extracInfo(IN vDisp int)
BEGIN
SELECT
	disp_dispensador.id_disp,
	disp_dispensador.serie_disp,
	disp_dispensador.hk_disp,
	disp_dispensador.ubicacion_disp,
	disp_dispensador.cliente_disp,
	disp_dispensador.planta_disp,
	disp_dispensador.activo_disp
FROM
	disp_dispensador
WHERE
	disp_dispensador.id_disp = vDisp;
END;

