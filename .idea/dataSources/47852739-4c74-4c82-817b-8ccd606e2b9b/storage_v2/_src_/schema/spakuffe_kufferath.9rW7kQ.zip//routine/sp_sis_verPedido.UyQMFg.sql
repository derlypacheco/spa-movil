create
    definer = root@localhost procedure sp_sis_verPedido(IN vFolio varchar(20))
BEGIN
SELECT
	sis_pedidos.folio_ped,
	sis_pedidos.id_pedido,
	sis_pedidos.fecha_ped,
	sis_pedidos.usuario_ped,
	sis_pedidos.estatus_ped,
	sis_pedidos.entrega_ped,
	sis_pedidos.activa_ped,
	concat( usuarios.nombre, " ", usuarios.apellidos ) AS solicito
FROM
	sis_pedidos
	INNER JOIN usuarios ON sis_pedidos.usuario_ped = usuarios.`user`
WHERE
	sis_pedidos.folio_ped = vFolio;
END;

