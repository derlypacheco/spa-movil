create
    definer = root@localhost procedure spRemoveTipoSalAlm(IN vID int, IN vUser varchar(15))
BEGIN
	UPDATE alm_tiposalidas set
	alm_tiposalidas.activo_tam = '0',
	alm_tiposalidas.user_tam = vUser
		WHERE
	alm_tiposalidas.id_salaml = vID;
END;

