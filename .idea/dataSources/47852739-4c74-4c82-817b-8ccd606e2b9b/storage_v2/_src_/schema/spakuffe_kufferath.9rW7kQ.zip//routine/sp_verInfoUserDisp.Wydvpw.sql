create
    definer = root@localhost procedure sp_verInfoUserDisp(IN vID int)
BEGIN
	SELECT
	disp_usuarios.id_user,
	disp_usuarios.clave_user,
	disp_usuarios.nombre_user,
	disp_usuarios.nivel_user,
	disp_usuarios.activo_user,
	disp_usuarios.dispensador_user,
	disp_usuarios.allDisp_user
FROM
	disp_usuarios
	where disp_usuarios.id_user = vID
	and disp_usuarios.activo_user = '1';
END;

