create
    definer = root@localhost procedure spListRelimgBancos(IN vID int)
BEGIN
SELECT
	bancos_rel.id_relban,
	bancos_rel.id_fban,
	bancos_rel.namepic_relban,
	bancos_rel.fecha_relban,
	bancos_rel.user_relban,
	bancos_rel.pic_relban,
	bancos_rel.activa_relban
FROM
	bancos_rel
WHERE
	bancos_rel.id_fban = vID;
END;

