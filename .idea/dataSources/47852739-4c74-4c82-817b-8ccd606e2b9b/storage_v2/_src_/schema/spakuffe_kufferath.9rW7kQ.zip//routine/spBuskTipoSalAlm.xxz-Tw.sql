create
    definer = root@localhost procedure spBuskTipoSalAlm(IN vNom varchar(150))
BEGIN
	SELECT * FROM alm_tiposalidas WHERE alm_tiposalidas.salida_tam = vNom;
END;

