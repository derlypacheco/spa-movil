create
    definer = root@localhost procedure sp_service_add_service(IN user_servicio varchar(50),
                                                              IN fecha_inicio varchar(200), IN clave_planta varchar(5),
                                                              IN creadoPor varchar(200), IN folio varchar(200),
                                                              IN servicio varchar(200), IN problema text,
                                                              IN contacto varchar(200), IN orden_trabajo varchar(200),
                                                              IN referencia varchar(200), IN planta varchar(3),
                                                              IN ins_equpos varchar(10), IN soporte varchar(10),
                                                              IN entkit varchar(10), IN capacitacion varchar(10),
                                                              IN programacion varchar(10), IN diasServ varchar(200),
                                                              IN noreporte varchar(200), IN name_contacto varchar(200))
BEGIN
INSERT INTO servicios 
(
user_servicio, 
fecha_inicio, 
clave_planta, 
creadoPor, 
folio, 
servicio, 
problema, 
contacto, 
orden_trabajo, 
referencia, 
planta, 
ins_equpos, 
soporte, 
entkit, 
capacitacion, 
programacion, 
diasServ, 
noreporte, 
name_contacto
) 
VALUES 
(
user_servicio, 
fecha_inicio, 
clave_planta, 
creadoPor, 
folio, 
servicio, 
problema, 
contacto, 
orden_trabajo, 
referencia, 
planta, 
ins_equpos, 
soporte, 
entkit, 
capacitacion, 
programacion, 
diasServ, 
noreporte, 
name_contacto
);
END;

