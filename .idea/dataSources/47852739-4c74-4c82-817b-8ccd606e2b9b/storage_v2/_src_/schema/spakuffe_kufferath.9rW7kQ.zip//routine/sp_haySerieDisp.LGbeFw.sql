create
    definer = root@localhost procedure sp_haySerieDisp(IN vSerie text)
BEGIN
	select * from disp_dispensador WHERE serie_disp = vSerie;
END;

