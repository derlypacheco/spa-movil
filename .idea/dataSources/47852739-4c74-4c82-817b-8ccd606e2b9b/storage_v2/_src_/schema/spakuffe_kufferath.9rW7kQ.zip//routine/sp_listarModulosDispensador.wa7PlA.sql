create
    definer = root@localhost procedure sp_listarModulosDispensador(IN vID int)
BEGIN
SELECT
disp_modulos.id_cliente_mod AS ID,
disp_modulos.noPart_mod AS Parte,
disp_modulos.numerom_mod as NumeroM,
disp_modulos.cant_cav_mod AS Cavidades,
disp_modulos.cant_det_mod AS Detecciones
FROM
disp_modulos
-- disp_relaciones
-- INNER JOIN disp_modulos ON disp_relaciones.id_modulo = disp_modulos.id_modulo
WHERE
	disp_modulos.disp_mod = vID
GROUP BY
	ID;
END;

