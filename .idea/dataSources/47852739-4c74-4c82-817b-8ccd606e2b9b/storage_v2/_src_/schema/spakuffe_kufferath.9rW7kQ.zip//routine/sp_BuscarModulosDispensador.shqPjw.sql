create
    definer = root@localhost procedure sp_BuscarModulosDispensador(IN vModulo varchar(150), IN vID int)
BEGIN
SELECT
disp_modulos.id_cliente_mod AS ID,
disp_modulos.noPart_mod AS Parte,
disp_modulos.cant_cav_mod AS Cavidades,
disp_modulos.cant_det_mod AS Detecciones
FROM
disp_relaciones
INNER JOIN disp_modulos ON disp_relaciones.id_modulo = disp_modulos.id_modulo
WHERE
	disp_modulos.id_cliente_mod = vModulo
	AND disp_relacion = vID
GROUP BY
	ID;
END;

