create
    definer = root@localhost procedure spListLA_disp(IN vLA varchar(50))
BEGIN
SELECT
	disp_inventariola.id_la_disp,
	disp_inventariola.prov_la_disp,
	disp_inventariola.numPart_Cliente_la_disp,
	disp_inventariola.numPart_Prov_la_disp,
	disp_inventariola.marcaProv_la_disp,
	disp_inventariola.coordX_la_disp,
	disp_inventariola.coordY_la_disp,
	disp_inventariola.tipo_la_disp,
	disp_inventariola.foto_la_disp,
	disp_inventariola.activo_la_disp,
	disp_inventariola.critico_la_disp,
	disp_inventariola.ideal_la_disp,
	disp_inventariola.existencia_la_disp,
	disp_inventariola.llave_la_disp,
	disp_inventariola.provalterno_la_disp,
  disp_inventariola.marcaprovalterno_la_disp
FROM
	disp_inventariola
WHERE
	disp_inventariola.numPart_Prov_la_disp = vLA;
END;

