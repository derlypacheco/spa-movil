create
    definer = root@localhost procedure sp_prod_listMesasUna(IN vID int)
BEGIN
	select * from prod_mesas where prod_mesas.activa_mesa = '1' and prod_mesas.id_prod_mesa = vID;
END;

