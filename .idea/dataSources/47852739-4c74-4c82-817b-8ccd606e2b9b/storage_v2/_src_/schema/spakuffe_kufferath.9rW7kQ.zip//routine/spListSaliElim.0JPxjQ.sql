create
    definer = root@localhost procedure spListSaliElim()
BEGIN
SELECT
	alm_salidas.id_sal,
	alm_salidas.fecha_sal,
	alm_salidas.user_sal,
	alm_salidas.folio_sal,
	alm_salidas.activo_sal,
	alm_salidas.tipo_sal,
	alm_salidas.idDepartamento,
	alm_salidas.estatus_sal,
	alm_salidas.solicito_sal,
	departamentos.departamento,
	alm_tiposalidas.salida_tam
FROM
	alm_salidas
	INNER JOIN departamentos ON alm_salidas.idDepartamento = departamentos.idDepartamento
	INNER JOIN alm_tiposalidas ON alm_salidas.tipo_sal = alm_tiposalidas.id_salaml
WHERE
	alm_salidas.activo_sal = '0';
END;

