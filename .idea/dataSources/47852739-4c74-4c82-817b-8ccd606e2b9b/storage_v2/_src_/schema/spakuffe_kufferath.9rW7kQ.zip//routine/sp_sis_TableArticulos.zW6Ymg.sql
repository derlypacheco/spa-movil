create
    definer = root@localhost procedure sp_sis_TableArticulos()
BEGIN
SELECT
	sis_productos.id_prod,
	sis_productos.fecha_prod,
	sis_productos.user_prod,
	sis_productos.stock_prod,
	sis_productos.categoria_prod,
	sis_productos.titulo_prod,
	sis_productos.des_prod,
	sis_productos.foto_prod,
	sis_productos.activo_prod,
	sis_categorias.nombre_cat
FROM
	sis_productos
	INNER JOIN sis_categorias ON sis_productos.categoria_prod = sis_categorias.id_cat
WHERE
	sis_productos.activo_prod = '1';
END;

