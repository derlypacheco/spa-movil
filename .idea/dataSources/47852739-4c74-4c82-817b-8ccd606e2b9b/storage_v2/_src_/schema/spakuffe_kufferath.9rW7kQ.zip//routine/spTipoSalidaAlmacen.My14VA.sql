create
    definer = root@localhost procedure spTipoSalidaAlmacen()
BEGIN
	SELECT
alm_tiposalidas.id_salaml,
alm_tiposalidas.salida_tam,
alm_tiposalidas.fecha_tam,
alm_tiposalidas.activo_tam,
CONCAT(usuarios.nombre, ' ', usuarios.apellidos) as nombre
FROM
	alm_tiposalidas
INNER JOIN usuarios ON alm_tiposalidas.user_tam = usuarios.`user`
WHERE
	alm_tiposalidas.activo_tam = '1';
END;

