create
    definer = root@localhost procedure sp_solLicenciaDisp(IN vSerie text, IN vUbicacion text, IN vCliente varchar(250),
                                                          IN vPlanta varchar(250), IN vCorreo varchar(250),
                                                          IN vGerente varchar(250))
BEGIN
INSERT INTO disp_dispensador
(serie_disp, ubicacion_disp, cliente_disp, planta_disp, activo_disp, correo_disp, gerente_disp)
VALUES
(vSerie, vUbicacion, vCliente, vPlanta, '0', vCorreo, vGerente);
END;

