create
    definer = root@localhost procedure sp_updateInfoDispensador(IN vSerie varchar(180), IN vHK varchar(180),
                                                                IN vUbic varchar(180), IN vCliente varchar(180),
                                                                IN vPlanta varchar(180), IN vDisp int)
BEGIN
UPDATE disp_dispensador
SET disp_dispensador.serie_disp = vSerie,
disp_dispensador.hk_disp = vHK,
disp_dispensador.ubicacion_disp = vUbic,
disp_dispensador.cliente_disp = vCliente,
disp_dispensador.planta_disp = vPlanta
WHERE
	disp_dispensador.id_disp = vDisp;
END;

