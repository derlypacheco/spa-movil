create
    definer = root@localhost procedure spEditarInventario(IN vMaterial int, IN vBarcode varchar(200), IN vDesc text,
                                                          IN vUser varchar(15), IN vSat varchar(200),
                                                          IN vFolio varchar(200))
BEGIN
	UPDATE alm_inventario SET
	alm_inventario.barcode_la = vBarcode,
	alm_inventario.desc_la = vDesc,
	alm_inventario.user_la = vUser,
	alm_inventario.clave_sat_la = vSat
	WHERE alm_inventario.name_la = vFolio;
END;

