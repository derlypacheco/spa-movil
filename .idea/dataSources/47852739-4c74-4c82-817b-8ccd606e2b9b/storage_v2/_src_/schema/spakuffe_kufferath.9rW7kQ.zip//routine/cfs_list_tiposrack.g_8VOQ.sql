create
    definer = root@localhost procedure cfs_list_tiposrack()
BEGIN
select id_tiporack, tiporack, desc_rack from cfs_tiporack where activo_rack = '1';
END;

