create
    definer = root@localhost procedure sp_prod_comitMesa(IN vID int)
BEGIN
SELECT
	prod_mesa_comit.id_comit_segMod,
	prod_mesa_comit.id_detmesa,
	prod_mesa_comit.user_comitMod,
	prod_mesa_comit.fecha_comitMod,
	prod_mesa_comit.coment_comitMod,
	prod_mesa_comit.activo_comitMod,
	prod_mesa_comit.file_comitMod,
	concat( usuarios.nombre, " ", usuarios.apellidos ) AS nombre,
	usuarios.foto
FROM
	prod_mesa_comit
	INNER JOIN usuarios ON prod_mesa_comit.user_comitMod = usuarios.`user`
WHERE
	prod_mesa_comit.activo_comitMod = '1' and prod_mesa_comit.id_detmesa = vID
ORDER BY prod_mesa_comit.id_comit_segMod DESC;
END;

