create
    definer = root@localhost procedure spAlmacenesDetalle(IN vFolio int)
BEGIN
	SELECT
	alm_inventario_cant.id_inv_cant,
	alm_inventario_cant.name_lacant,
	alm_inventario_cant.fecha_lacant,
	alm_inventario_cant.user_lacant,
	alm_inventario_cant.activo_lacant,
	alm_inventario_cant.exist_lacant,
	alm_inventario_cant.min_lacant,
	alm_inventario_cant.max_lacant,
	alm_inventario_cant.costo_lacant,
	alm_inventario_cant.almacen_lacant,
	alm_inventario_cant.id_alm_lacant,
	CONCAT(usuarios.nombre, ' ', usuarios.apellidos) as nombre
	FROM
	alm_inventario_cant
	INNER JOIN usuarios ON alm_inventario_cant.user_lacant = usuarios.`user`
	WHERE alm_inventario_cant.id_inv_cant = vFolio;
END;

