create
    definer = root@localhost procedure spListDetalleSalida(IN vfolio varchar(15))
BEGIN
SELECT
alm_relsalidas.folio_rsal,
alm_relsalidas.fecha_rsal,
alm_relsalidas.user_rsal,
alm_relsalidas.la_rsal,
alm_inventario.desc_la,
alm_relsalidas.cant_rsal,
alm_relsalidas.costo_rsal,
alm_relsalidas.total_sal,
alm_relsalidas.solicito_sal,
CONCAT(usuarios.nombre, ' ', usuarios.apellidos) as nombre
FROM
alm_relsalidas
INNER JOIN alm_inventario ON alm_relsalidas.la_rsal = alm_inventario.name_la
INNER JOIN usuarios ON alm_relsalidas.user_rsal = usuarios.`user`
WHERE
alm_relsalidas.folio_rsal = vfolio and alm_relsalidas.activo_sal = '1';
END;

