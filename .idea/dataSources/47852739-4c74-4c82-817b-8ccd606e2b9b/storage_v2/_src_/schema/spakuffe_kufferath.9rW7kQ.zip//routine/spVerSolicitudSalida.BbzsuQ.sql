create
    definer = root@localhost procedure spVerSolicitudSalida(IN vID int)
BEGIN
		SELECT
alm_salidas.id_sal,
alm_salidas.fecha_sal,
alm_salidas.user_sal,
alm_salidas.folio_sal,
alm_salidas.activo_sal,
alm_salidas.tipo_sal,
alm_salidas.idDepartamento,
alm_salidas.estatus_sal,
alm_salidas.solicito_sal,
CONCAT(usuarios.nombre, ' ', usuarios.apellidos) as nombre
FROM
alm_salidas
INNER JOIN usuarios ON alm_salidas.user_sal = usuarios.`user`
WHERE
alm_salidas.activo_sal = '1' AND
alm_salidas.id_sal = vID;
END;

