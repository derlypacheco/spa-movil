create
    definer = root@localhost procedure spAddTipoLA(IN vTipoLA varchar(220), IN vUser varchar(15), IN vFecha datetime)
BEGIN
	INSERT INTO alm_tipola
	(alm_tipola.tipo_tla, alm_tipola.user_tla, alm_tipola.fecha_tla)
		VALUES
	(vTipoLA, vUser, vFecha);
END;

