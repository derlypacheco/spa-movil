create
    definer = root@localhost procedure sp_sis_creaPedido(IN vFolio varchar(25), IN vUser varchar(15))
BEGIN
insert into sis_pedidos
(folio_ped, fecha_ped, usuario_ped)
values
(vFolio, CURRENT_TIMESTAMP, vUser);
END;

