create
    definer = root@localhost procedure spConsultaLA(IN numla varchar(15))
BEGIN
	SELECT
alm_inventario.id_inv,
alm_inventario.name_la,
alm_inventario.clave_alm,
alm_inventario.fecha_la,
alm_inventario.user_la,
alm_inventario.activo_la,
alm_inventario.exist_la,
alm_inventario.min_la,
alm_inventario.max_la,
alm_inventario.clave_sat_la,
alm_inventario.costo_la,
alm_inventario.id_tla,
alm_inventario.barcode_la,
alm_inventario.locacion_la,
alm_inventario.campo1_la,
alm_inventario.campo2_la
FROM
alm_inventario
WHERE
alm_inventario.name_la = numla and alm_inventario.activo_la = '1';
END;

