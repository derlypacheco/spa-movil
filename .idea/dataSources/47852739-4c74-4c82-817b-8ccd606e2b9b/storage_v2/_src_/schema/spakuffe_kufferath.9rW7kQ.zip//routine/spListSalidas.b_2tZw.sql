create
    definer = root@localhost procedure spListSalidas()
BEGIN
SELECT
alm_salidas.id_sal,
alm_salidas.fecha_sal,
alm_salidas.user_sal,
alm_salidas.folio_sal,
alm_salidas.activo_sal,
alm_salidas.tipo_sal,
alm_salidas.estatus_sal
FROM
alm_salidas
WHERE
	alm_salidas.activo_sal = '1'
ORDER BY alm_salidas.estatus_sal asc;
END;

