create
    definer = root@localhost procedure sp_rutaManual(IN vID int)
BEGIN
SELECT
	disp_manuales.ruta_disp
FROM
	disp_manuales
WHERE
	disp_manuales.id_table = vID;
END;

