create
    definer = root@localhost procedure sp_ListLineasPlanta(IN vDispensador varchar(15))
BEGIN
SELECT disp_Lineas.linea_lndisp as Linea 
FROM 
disp_Lineas 
WHERE 
disp_Lineas.dispendador_linea = vDispensador;
END;

