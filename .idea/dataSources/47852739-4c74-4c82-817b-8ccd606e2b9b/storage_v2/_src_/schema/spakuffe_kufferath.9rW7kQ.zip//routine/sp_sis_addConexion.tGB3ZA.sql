create
    definer = root@localhost procedure sp_sis_addConexion(IN vFolio varchar(25), IN vCat int, IN vCant decimal(6),
                                                          IN vUser varchar(15))
BEGIN
insert into sis_conexiones
(folio_conex, id_prod_conex, user_conex, cant_conex, fecha_conex)
values
(vFolio, vCat, vUser, vCant, CURRENT_DATE);
END;

