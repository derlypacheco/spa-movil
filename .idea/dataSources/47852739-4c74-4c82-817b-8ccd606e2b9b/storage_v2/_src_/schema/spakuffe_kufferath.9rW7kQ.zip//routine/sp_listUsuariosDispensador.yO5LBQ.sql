create
    definer = root@localhost procedure sp_listUsuariosDispensador(IN vDisp int)
BEGIN
SELECT
	disp_usuarios.id_user AS ID,
	disp_usuarios.nombre_user AS Nombre,
	disp_usuarios.nivel_user AS Nivel
FROM
	disp_usuarios
WHERE
	activo_user = '1'
	AND dispensador_user = vDisp;
END;

