create
    definer = root@localhost procedure sp_hk_listComit(IN vFolio varchar(100))
SELECT
	concat(
		usuarios.nombre ,
		' ' ,
		usuarios.apellidos
	) AS nombre ,
	usuarios.foto ,
	hk_comitorden.comit_id ,
	hk_comitorden.folio_comit ,
	hk_comitorden.fecha_comit ,
	hk_comitorden.file_comit ,
	hk_comitorden.desc_comit
FROM
	hk_comitorden
JOIN usuarios ON hk_comitorden.user_comit = usuarios.`user`
WHERE
	hk_comitorden.activo_comit = '1' and
	hk_comitorden.folio_comit = vFolio
ORDER BY
	hk_comitorden.comit_id ASC;

