create
    definer = root@localhost procedure sp_prod_modDet(IN vID int, IN vCod varchar(25))
begin
	select * from prod_mesa_detalle where
	prod_mesa_detalle.id_prod_mesa = vID and
	prod_mesa_detalle.pos_detmesa = vCod;
end;

