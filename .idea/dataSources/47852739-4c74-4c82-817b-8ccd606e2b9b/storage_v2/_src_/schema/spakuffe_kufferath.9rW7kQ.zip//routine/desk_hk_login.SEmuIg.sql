create
    definer = root@localhost procedure desk_hk_login(IN txtUser varchar(25), IN txtPass varchar(120))
BEGIN
select * from usuarios where usuarios.`user` = txtUser and usuarios.`password` = sha1(txtPass);
END;

