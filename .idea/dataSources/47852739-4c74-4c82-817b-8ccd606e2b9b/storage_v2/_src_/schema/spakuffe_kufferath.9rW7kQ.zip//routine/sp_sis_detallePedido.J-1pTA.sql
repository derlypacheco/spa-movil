create
    definer = root@localhost procedure sp_sis_detallePedido(IN vFolio varchar(20))
BEGIN
	#Routine body goes here... MVO423
SELECT
	sis_conexiones.folio_conex,
	sis_conexiones.cant_conex,
	sis_conexiones.fecha_conex,
	sis_productos.stock_prod,
	sis_productos.titulo_prod,
	sis_productos.categoria_prod,
	sis_productos.foto_prod,
	sis_productos.des_prod
FROM
	sis_conexiones
	INNER JOIN sis_productos ON sis_conexiones.id_prod_conex = sis_productos.id_prod
WHERE
	sis_conexiones.folio_conex = vFolio;
END;

