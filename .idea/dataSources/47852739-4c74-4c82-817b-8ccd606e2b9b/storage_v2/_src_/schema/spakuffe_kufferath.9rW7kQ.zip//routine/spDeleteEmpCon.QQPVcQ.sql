create
    definer = root@localhost procedure spDeleteEmpCon(IN idF int)
BEGIN
	DELETE FROM empresa_con where id_empCon = idF;
END;

