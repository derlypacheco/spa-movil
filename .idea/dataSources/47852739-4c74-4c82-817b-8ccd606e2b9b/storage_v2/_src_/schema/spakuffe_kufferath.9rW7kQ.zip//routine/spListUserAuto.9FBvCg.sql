create
    definer = root@localhost procedure spListUserAuto()
BEGIN
SELECT * from alm_userauto WHERE alm_userauto.activo_au = '1';
END;

