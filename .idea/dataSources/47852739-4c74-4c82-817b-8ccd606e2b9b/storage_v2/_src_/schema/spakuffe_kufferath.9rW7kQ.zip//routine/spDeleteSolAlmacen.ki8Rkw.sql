create
    definer = root@localhost procedure spDeleteSolAlmacen(IN vID int, IN vUser varchar(15))
BEGIN
	UPDATE alm_salidas SET
		alm_salidas.activo_sal = '0',
		alm_salidas.user_sal = vUser
	WHERE
		alm_salidas.id_sal = vID;
END;

