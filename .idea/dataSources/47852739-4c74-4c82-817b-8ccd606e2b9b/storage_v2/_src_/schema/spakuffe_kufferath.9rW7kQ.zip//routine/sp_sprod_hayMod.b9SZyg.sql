create
    definer = root@localhost procedure sp_sprod_hayMod(IN vID int, IN vCod varchar(50))
BEGIN
	select count(*) as total from prod_mesa_detalle where prod_mesa_detalle.pos_detmesa = vCod and prod_mesa_detalle.id_prod_mesa = vID;
END;

