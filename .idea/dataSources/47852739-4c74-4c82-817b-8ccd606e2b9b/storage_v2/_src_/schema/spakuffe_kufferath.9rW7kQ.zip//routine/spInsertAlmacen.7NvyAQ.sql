create
    definer = root@localhost procedure spInsertAlmacen(IN cFol int(4), IN vAlm varchar(150), IN vDesc text,
                                                       IN vUser varchar(15), IN vDate datetime)
BEGIN
	INSERT INTO alm_almacenes
	(
	clave_alm,
	almacen_alm,
	desc_alm,
	user_alm,
	fecha_alm
	)
	VALUES
	(
	cFol,
	vAlm,
	vDesc,
	vUser,
	vDate
	);
END;

