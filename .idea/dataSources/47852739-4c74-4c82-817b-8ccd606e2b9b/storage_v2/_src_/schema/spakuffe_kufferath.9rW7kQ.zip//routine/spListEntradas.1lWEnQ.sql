create
    definer = root@localhost procedure spListEntradas()
BEGIN
	SELECT
alm_entradas.id_en,
alm_entradas.fecha_en,
alm_entradas.user_en,
alm_entradas.folio_en,
alm_entradas.activo_en,
alm_entradas.cfdi_en,
alm_entradas.desc_en
FROM
alm_entradas
WHERE
activo_en = '1';
END;

