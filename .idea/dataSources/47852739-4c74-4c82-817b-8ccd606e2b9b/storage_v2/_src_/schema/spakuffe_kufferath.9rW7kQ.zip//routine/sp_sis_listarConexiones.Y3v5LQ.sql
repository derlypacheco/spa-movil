create
    definer = root@localhost procedure sp_sis_listarConexiones(IN vFolio varchar(20))
BEGIN
	SELECT
	sis_conexiones.cant_conex,
	sis_conexiones.fecha_conex,
	sis_productos.titulo_prod
FROM
	sis_conexiones
	INNER JOIN sis_productos ON sis_conexiones.id_prod_conex = sis_productos.id_prod
	WHERE sis_conexiones.folio_conex = vFolio;
END;

