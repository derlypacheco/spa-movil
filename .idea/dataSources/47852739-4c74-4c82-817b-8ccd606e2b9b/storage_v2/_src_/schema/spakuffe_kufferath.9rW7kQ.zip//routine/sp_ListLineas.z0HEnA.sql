create
    definer = root@localhost procedure sp_ListLineas(IN vDisp varchar(15))
BEGIN
	SELECT *
	FROM disp_Lineas
	WHERE
	disp_Lineas.activo_linea = '1'
	and
	disp_Lineas.dispendador_linea = vDisp;
END;

