create
    definer = root@localhost procedure sp_servClienteAdd(IN vFolio varchar(50), IN vEstatus varchar(3),
                                                         IN vServicio varchar(200), IN vDesc text,
                                                         IN vOrden varchar(50), IN vReferencia varchar(50),
                                                         IN vPlanta char(3), IN vEquipos char, IN vSoporte char,
                                                         IN vKit char, IN vCapa char, IN vProg char,
                                                         IN vClavePlanta char(5), IN vNombre varchar(230))
BEGIN
insert into servicios
(
folio,
estatus,
servicio,
problema,
orden_trabajo,
referencia,
planta,
ins_equpos,
soporte,
entKit,
capacitacion,
programacion,
clave_planta,
creadoPor,
fecha_inicio
)
values
(
vFolio,
vEstatus,
vServicio,
vDesc,
vOrden,
vReferencia,
vPlanta,
vEquipos,
vSoporte,
vKit,
vCapa,
vProg,
vClavePlanta,
vNombre,
CURRENT_TIMESTAMP
);
END;

