create
    definer = root@localhost procedure sp_NuevoModulo(IN vIdCliente varchar(10), IN vParte varchar(20),
                                                      IN vCavidades int(10), IN vDetecciones int(10),
                                                      IN vUser varchar(15), IN vDispensador varchar(50),
                                                      IN vDesc varchar(16), IN vKey varchar(10), IN vModulo varchar(80))
BEGIN
	INSERT INTO disp_modulos (id_cliente_mod, noPart_mod, cant_cav_mod, cant_det_mod, user_mod, disp_mod, desc_mod, key_mod, numerom_mod)
	VALUES
	(vIdCliente, vParte, vCavidades, vDetecciones, vUser, vDispensador, vDesc, vKey, vModulo);
END;

