create
    definer = root@localhost procedure spListDepartamentos()
BEGIN
	SELECT
departamentos.idDepartamento,
departamentos.departamento,
departamentos.`user`,
departamentos.clave_planta,
departamentos.fechaC
	FROM
departamentos
	WHERE
departamentos.activo = '1';
END;

