create
    definer = root@localhost procedure sp_get_amountProcess()
BEGIN

declare AMOUNT_CURRENT double;
declare INVOICE double;
declare PROCESS double;

set AMOUNT_CURRENT = (select sum(amount_process) as total from hk_process_orders where ponum_process != 'Complete');
set INVOICE = (select sum(cant_invoice) as total from hk_process_orders_rel where active_incoice = '1');
set PROCESS = (select AMOUNT_CURRENT) - (select INVOICE);

select AMOUNT_CURRENT, INVOICE, PROCESS;

END;

