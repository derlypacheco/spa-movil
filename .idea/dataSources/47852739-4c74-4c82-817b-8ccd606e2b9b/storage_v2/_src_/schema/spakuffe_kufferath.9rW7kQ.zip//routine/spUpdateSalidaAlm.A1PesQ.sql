create
    definer = root@localhost procedure spUpdateSalidaAlm(IN vDep int, IN vEstatus char, IN vTipo int, IN vFolio varchar(15))
BEGIN

	UPDATE alm_salidas SET
		alm_salidas.idDepartamento = vDep,
		alm_salidas.tipo_sal = vTipo,
		alm_salidas.estatus_sal = vEstatus
 WHERE
		alm_salidas.folio_sal = vFolio;
END;

