create
    definer = root@localhost procedure spRemoveTipoLA(IN vFolio int, IN vUser varchar(15))
BEGIN
	UPDATE alm_tipola SET
		alm_tipola.activo_tla = '0',
		alm_tipola.user_tla = vUser
	WHERE
		alm_tipola.id_tla = vFolio;
END;

