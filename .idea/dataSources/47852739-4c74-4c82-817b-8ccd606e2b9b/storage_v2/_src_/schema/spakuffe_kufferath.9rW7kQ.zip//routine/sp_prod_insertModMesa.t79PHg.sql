create
    definer = root@localhost procedure sp_prod_insertModMesa(IN vID int, IN vPost varchar(10), IN vEstatus char,
                                                             IN vUser varchar(15), IN vFoto text, IN vQR text,
                                                             IN vNum varchar(30), IN vDesc text,
                                                             IN vQRbanco varchar(150))
BEGIN
insert into prod_mesa_detalle
(id_prod_mesa, pos_detmesa, estatus_detmesa, user_detmesa, foto_detmesa, code__detmesa, numero_detmesa, desc_detmesa, fecha_detmesa, qrbanco_detmesa)
values
(vID, vPost, vEstatus, vUser, vFoto, vQR, vNum, vDesc, CURRENT_TIMESTAMP, vQRbanco);
END;

