create
    definer = root@localhost procedure sp_list_gastps()
BEGIN
select * from gastos;
END;

