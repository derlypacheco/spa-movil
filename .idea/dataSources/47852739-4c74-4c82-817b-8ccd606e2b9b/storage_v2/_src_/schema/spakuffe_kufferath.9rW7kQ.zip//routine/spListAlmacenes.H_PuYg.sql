create
    definer = root@localhost procedure spListAlmacenes()
BEGIN
	SELECT
alm_almacenes.id_alm,
alm_almacenes.clave_alm,
alm_almacenes.almacen_alm,
alm_almacenes.fecha_alm,
alm_almacenes.activo_alm,
alm_almacenes.user_alm,
alm_almacenes.desc_alm,
CONCAT(usuarios.nombre, ' ', usuarios.apellidos) as nombre
FROM
alm_almacenes
INNER JOIN usuarios ON alm_almacenes.user_alm = usuarios.`user`
WHERE
alm_almacenes.activo_alm = '1';
END;

