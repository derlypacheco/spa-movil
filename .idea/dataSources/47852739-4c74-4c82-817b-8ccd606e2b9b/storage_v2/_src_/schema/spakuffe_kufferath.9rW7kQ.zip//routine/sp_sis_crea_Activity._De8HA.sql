create
    definer = root@localhost procedure sp_sis_crea_Activity(IN vFolio varchar(20), IN vUser varchar(15), IN vCont text,
                                                            IN vFile text)
BEGIN
insert into sis_seguimiento
(folio_seg, user_seg, fecha_seg, coment_seg, file_seg)
values
(vFolio, vUser, CURRENT_TIMESTAMP, vCont, vFile);
END;

