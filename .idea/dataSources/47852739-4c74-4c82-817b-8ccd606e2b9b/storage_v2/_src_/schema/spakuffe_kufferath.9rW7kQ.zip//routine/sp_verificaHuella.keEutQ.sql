create
    definer = root@localhost procedure sp_verificaHuella(IN vDisp int)
BEGIN
SELECT
	huella_user
FROM
	disp_usuarios
WHERE
	disp_usuarios.dispensador_user = vDisp
ORDER BY
	huella_user DESC;
END;

