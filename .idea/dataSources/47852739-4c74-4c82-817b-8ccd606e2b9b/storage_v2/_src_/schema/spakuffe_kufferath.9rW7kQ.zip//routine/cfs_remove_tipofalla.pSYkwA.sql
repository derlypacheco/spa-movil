create
    definer = root@localhost procedure cfs_remove_tipofalla(IN ID int)
BEGIN
update cfs_tipofalla set activo_falla = '0' where id_tipofalla = ID;
END;

