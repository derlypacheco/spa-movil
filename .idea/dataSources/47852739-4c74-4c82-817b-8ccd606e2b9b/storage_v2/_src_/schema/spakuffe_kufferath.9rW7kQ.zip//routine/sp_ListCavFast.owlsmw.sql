create
    definer = root@localhost procedure sp_ListCavFast(IN vFol varchar(20))
BEGIN
	SELECT
	disp_relaciones.id_relaciones as ID,
	cavidad_relacion as Cavidad,
	id_la_disp as ID_LA
	FROM disp_relaciones
	WHERE
	key_relacion = vFol
	AND cavidad_relacion LIKE '%CAV%';
END;

