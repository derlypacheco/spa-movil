create
    definer = root@localhost procedure sp_hk_addCliente(IN vCliente varchar(200), IN vCorreo varchar(200),
                                                        IN vUser varchar(20))
insert into hk_clientes
(cliente_clie, mail_clie, user_clie, fecha_clie)
 values
(vCliente, vCorreo, vUser, CURRENT_TIMESTAMP());

