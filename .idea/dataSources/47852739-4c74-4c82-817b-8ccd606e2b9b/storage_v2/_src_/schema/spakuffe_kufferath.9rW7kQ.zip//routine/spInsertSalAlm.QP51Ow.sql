create
    definer = root@localhost procedure spInsertSalAlm(IN vfecha datetime, IN vuser varchar(10), IN vfolio varchar(10),
                                                      IN vtipo int, IN vdep int, IN estatus char)
BEGIN
	INSERT INTO alm_salidas (fecha_sal, user_sal, folio_sal, tipo_sal, idDepartamento, estatus_sal)
	VALUES (vfecha, vuser, vfolio, vtipo, vdep, estatus);
END;

