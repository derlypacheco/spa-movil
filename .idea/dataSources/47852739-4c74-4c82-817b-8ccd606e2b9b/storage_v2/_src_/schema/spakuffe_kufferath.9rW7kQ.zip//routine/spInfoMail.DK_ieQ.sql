create
    definer = root@localhost procedure spInfoMail(IN vFolio varchar(180))
SELECT
CONCAT(usuarios.nombre, ' ', usuarios.apellidos) AS nombre,
gastos.folioFiscal,
gastos.folio_com,
gastos.importe_gasto,
usuarios.correo,
usuarios.mail_jefe
FROM
gastos
INNER JOIN usuarios ON gastos.user_gasto = usuarios.`user`
WHERE
gastos.folioFiscal = vFolio;

