create
    definer = root@localhost procedure spListUsuarios()
BEGIN
	SELECT
	usuarios.`user`,
	usuarios.nombre,
	usuarios.apellidos,
	usuarios.departamento,
	usuarios.cargo,
	usuarios.registro,
	usuarios.correo,
	empresas.nombre_emp,
	empresas.logo_emp,
	permisos.Permiso
FROM
	usuarios
	INNER JOIN empresas ON usuarios.empresa = empresas.codigo_emp
	INNER JOIN permisos ON usuarios.id_permiso = permisos.id_permiso;
END;

