create
    definer = root@localhost procedure spInsertEmpCon(IN nameEmp varchar(80), OUT result int(1))
BEGIN
  DECLARE rows int;
	SELECT count(empresa_con) INTO result
	FROM empresa_con
	where empresa_con = nameEmp COLLATE utf8_general_ci; -- Busqueda si hay
	SET rows = result;
		IF rows = 0 THEN
	    INSERT INTO empresa_con (empresa_con) VALUES (nameEmp); -- Insertar la empresa para los conectores.
    END IF;
END;

