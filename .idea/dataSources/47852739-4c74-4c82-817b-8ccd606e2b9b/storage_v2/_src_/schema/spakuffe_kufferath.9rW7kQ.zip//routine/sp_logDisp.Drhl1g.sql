create
    definer = root@localhost procedure sp_logDisp(IN vDisp varchar(180), IN vProcesador varchar(180),
                                                  IN vBios varchar(180), IN vBroad varchar(180), IN vMarca varchar(180),
                                                  IN vModelo varchar(180), IN vSerie varchar(180))
BEGIN
INSERT INTO disp_logs ( id_dispensador, procesador_log, biosversion_log, broadProd_log, marca_log, modelVer_log, seriePC_log )
VALUES
	( vDisp, vProcesador, vBios, vBroad, vMarca, vModelo, vSerie );
END;

