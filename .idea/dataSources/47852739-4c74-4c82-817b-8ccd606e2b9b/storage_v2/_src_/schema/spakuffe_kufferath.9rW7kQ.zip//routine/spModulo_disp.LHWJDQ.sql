create
    definer = root@localhost procedure spModulo_disp(IN vModulo varchar(5))
BEGIN
SELECT
	disp_modulos.id_cliente_mod as IDCliente,
	disp_modulos.noPart_mod as NoParte,
	disp_modulos.cant_cav_mod as Cavidades,
	disp_modulos.cant_det_mod as Detecciones
FROM
	disp_modulos
WHERE
	disp_modulos.id_cliente_mod = vModulo;
END;

