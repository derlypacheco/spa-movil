create
    definer = root@localhost procedure sp_hk_addComit(IN vFolio varchar(100), IN vUser varchar(20), IN vFile text,
                                                      IN vComit text)
insert into hk_comitorden
(folio_comit, fecha_comit, user_comit, file_comit, desc_comit)
values
(vFolio, CURRENT_TIMESTAMP(), vUser, vFile, vComit);

