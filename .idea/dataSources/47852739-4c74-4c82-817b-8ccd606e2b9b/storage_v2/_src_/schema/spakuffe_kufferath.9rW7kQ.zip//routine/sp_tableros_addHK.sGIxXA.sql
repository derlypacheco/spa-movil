create
    definer = root@localhost procedure sp_tableros_addHK(IN vOrden varchar(150), IN vLocation int, IN vDesc text,
                                                         IN vUser varchar(15), IN vKey varchar(50))
BEGIN
	INSERT INTO ordenes
		(fecha_cap, orden, id_locacion, porcentaje, `status`, descripcion, user_cap, key_master)
	VALUES
		(CURRENT_TIMESTAMP, vOrden, vLocation, '10', '1', vDesc, vUser, vKey);
END;

