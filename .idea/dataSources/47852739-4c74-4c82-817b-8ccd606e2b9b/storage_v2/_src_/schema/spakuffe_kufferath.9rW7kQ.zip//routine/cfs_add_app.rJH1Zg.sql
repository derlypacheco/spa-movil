create
    definer = root@localhost procedure cfs_add_app(IN titulo varchar(180), IN version varchar(8), IN ruta_app longtext,
                                                   IN usuario varchar(30), IN label varchar(5), IN visible char,
                                                   IN ruta_logo longtext)
BEGIN
	insert into cfs_apps 
	(
		title_apps,
		fecha_apps,
		version_apps,
		archivo_apps,
		user_apps,
		logo_apps,
		label_apps,
		v_dash
	) 
	values 
	(
		titulo,
		CURRENT_TIMESTAMP(),
		version,
		ruta_app,
		usuario,
		ruta_logo,
		label,
		visible
	);
	END;

