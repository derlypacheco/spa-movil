create
    definer = root@localhost procedure spInfoGasto(IN vFolio varchar(200))
BEGIN
SELECT
gastos.id_gasto,
gastos.fecha_gasto,
gastos.rfc_gasto,
gastos.folioFiscal,
gastos.importe_gasto,
gastos.folio_com,
gastos.activo_gasto,
gastos.xml_gasto,
gastos.cfdi_gasto,
gastos.razon_social_gasto,
gastos.user_gasto,
gastos.tipo_gasto,
gastos.date_Gasto,
gastos.txt_gasto,
gastos.absorber,
gastos.con_factura,
CONCAT(usuarios.nombre, ' ', usuarios.apellidos) as nombre
FROM
gastos
INNER JOIN usuarios ON gastos.user_gasto = usuarios.`user`
WHERE folioFiscal = vFolio;
END;

