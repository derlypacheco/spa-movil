create
    definer = root@localhost procedure spEditAlmacen(IN vID int, IN vUser varchar(15), IN vAlmacen varchar(180),
                                                     IN vDesc varchar(250))
BEGIN
	UPDATE alm_almacenes SET
		alm_almacenes.almacen_alm = vAlmacen,
		alm_almacenes.user_alm = vUser,
		alm_almacenes.desc_alm = vDesc
	WHERE
		alm_almacenes.id_alm = vID;
END;

