create
    definer = root@localhost procedure sp_consultaInventario(IN vID int, IN vResult int)
BEGIN
	update disp_relaciones set
	disp_relaciones.stock_relacion = vResult
	WHERE
	disp_relaciones.id_relaciones = vID;
END;

