create
    definer = root@localhost procedure spEsitDetalleAlmacen(IN vAlmacen varchar(10), IN vExist int, IN vMinimo int,
                                                            IN vMaximo int, IN vCosto int, IN vFolio int,
                                                            IN vUser varchar(15))
BEGIN
	UPDATE alm_inventario_cant SET
	alm_inventario_cant.exist_lacant = vExist,
	alm_inventario_cant.min_lacant = vMinimo,
	alm_inventario_cant.max_lacant = vMaximo,
	alm_inventario_cant.costo_lacant = vCosto,
	alm_inventario_cant.user_lacant = vUser
	WHERE
	alm_inventario_cant.id_inv_cant = vFolio;
END;

