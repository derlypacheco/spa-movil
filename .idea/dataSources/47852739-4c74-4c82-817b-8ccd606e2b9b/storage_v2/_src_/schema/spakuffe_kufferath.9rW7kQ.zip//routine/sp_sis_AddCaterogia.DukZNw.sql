create
    definer = root@localhost procedure sp_sis_AddCaterogia(IN vUser varchar(15), IN vCat varchar(25))
BEGIN
insert into sis_categorias
(nombre_cat, user_cat, fecha_cat)
values 
(vCat, vUser, CURRENT_TIMESTAMP);
END;

