create
    definer = root@localhost procedure spTableExistAlmacen(IN vLA varchar(150))
BEGIN
SELECT
alm_inventario_cant.id_inv_cant,
alm_inventario_cant.name_lacant,
alm_inventario_cant.fecha_lacant,
alm_inventario_cant.user_lacant,
alm_inventario_cant.activo_lacant,
alm_inventario_cant.exist_lacant,
alm_inventario_cant.min_lacant,
alm_inventario_cant.max_lacant,
alm_inventario_cant.costo_lacant,
alm_inventario_cant.almacen_lacant,
alm_almacenes.almacen_alm
FROM
alm_inventario_cant
INNER JOIN alm_almacenes ON alm_inventario_cant.almacen_lacant = alm_almacenes.clave_alm
WHERE
alm_inventario_cant.name_lacant = vLA and
alm_inventario_cant.activo_lacant = '1';
END;

