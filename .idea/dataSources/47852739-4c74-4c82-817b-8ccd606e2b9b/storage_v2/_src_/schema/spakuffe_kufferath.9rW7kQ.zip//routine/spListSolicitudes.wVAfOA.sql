create
    definer = root@localhost procedure spListSolicitudes(IN vIF varchar(180))
BEGIN

	SELECT
alm_salidas.id_sal,
alm_salidas.fecha_sal,
alm_salidas.user_sal,
alm_salidas.folio_sal,
alm_salidas.activo_sal,
alm_salidas.estatus_sal,
departamentos.departamento,
CONCAT(usuarios.nombre, ' ', usuarios.apellidos) AS solicito,
alm_tiposalidas.salida_tam
	FROM
alm_salidas
	INNER JOIN departamentos ON alm_salidas.idDepartamento = departamentos.idDepartamento
	INNER JOIN usuarios ON alm_salidas.solicito_sal = usuarios.`user`
	INNER JOIN alm_tiposalidas ON alm_salidas.tipo_sal = alm_tiposalidas.id_salaml;

END;

