create
    definer = root@localhost procedure sp_insertUserDisp(IN vNombre varchar(220), IN vPass varchar(220),
                                                         IN vPermiso varchar(220), IN vHuella int, IN vDisp int)
BEGIN
	insert into disp_usuarios (nombre_user, nivel_user, dispensador_user, clave_user, huella_user)
	values
	(vNombre, vPermiso, vDisp, vPass, vHuella);
END;

