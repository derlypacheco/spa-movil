create
    definer = root@localhost procedure Csp_pedidos_ListarPed(IN vUser varchar(15))
BEGIN
	SELECT * FROM sis_pedidos WHERE sis_pedidos.activa_ped = '1';
END;

