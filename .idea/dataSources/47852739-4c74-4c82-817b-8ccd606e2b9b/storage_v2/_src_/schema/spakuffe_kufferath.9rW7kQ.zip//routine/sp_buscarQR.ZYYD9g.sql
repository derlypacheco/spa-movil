create
    definer = root@localhost procedure sp_buscarQR(IN vQR varchar(25), IN vDispensador int)
BEGIN
SELECT
	disp_relaciones.id_relaciones,
	disp_inventariola.prov_la_disp,
	disp_inventariola.numPart_Prov_la_disp,
	disp_inventariola.tipo_la_disp,
	disp_inventariola.foto_la_disp,
	disp_relaciones.pinBlock_relacion,
	disp_relaciones.coorx_relacion,
	disp_relaciones.coory_relacion,
	disp_relaciones.key_relacion,
	disp_relaciones.pinContador_relacion,
	disp_relaciones.disp_relacion,
	disp_relaciones.linea_relacion,
	disp_relaciones.cavidad_relacion,
	disp_relaciones.stock_relacion,
	disp_relaciones.min_stock_relacion,
	disp_relaciones.max_stock_relacion,
	disp_modulos.noPart_mod,
	disp_modulos.key_mod,
	disp_modulos.numerom_mod
FROM
	disp_inventariola
	INNER JOIN disp_relaciones ON disp_inventariola.id_la_disp = disp_relaciones.id_la_disp
	INNER JOIN disp_modulos ON disp_relaciones.id_modulo = disp_modulos.id_modulo
WHERE
	numPart_Prov_la_disp = vQR
AND
	disp_relacion = vDispensador
GROUP BY
	numPart_Prov_la_disp;

END;

