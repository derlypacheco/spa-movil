create
    definer = root@localhost procedure spInsertTabSalidaLA(IN vfolio varchar(10), IN vfecha datetime,
                                                           IN vuser varchar(10), IN vla varchar(15), IN vcant int,
                                                           IN vcosto int, IN vtotal int)
BEGIN
	INSERT INTO alm_relsalidas
(folio_rsal, fecha_rsal, user_rsal, la_rsal, cant_rsal, costo_rsal, total_sal)
VALUES
(vfolio, vfecha, vuser, vla, vcant, vcosto, vtotal);
END;

