create
    definer = root@localhost procedure sp_hk_dropImgModulo(IN id int)
BEGIN
DELETE FROM hk_rel_imgModulos WHERE id_relFoto = id;
END;

