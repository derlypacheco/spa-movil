create
    definer = root@localhost procedure sp_sis_addProducto(IN vUser varchar(15), IN vCant decimal, IN vCategoria int,
                                                          IN vTitulo varchar(150), IN vDesc text, IN vFoto text)
BEGIN
INSERT INTO sis_productos
	(fecha_prod, user_prod, stock_prod, categoria_prod, titulo_prod, des_prod, foto_prod)
VALUES
	(CURRENT_TIMESTAMP, vUser, vCant, vCategoria, vTitulo, vDesc, vFoto);
END;

