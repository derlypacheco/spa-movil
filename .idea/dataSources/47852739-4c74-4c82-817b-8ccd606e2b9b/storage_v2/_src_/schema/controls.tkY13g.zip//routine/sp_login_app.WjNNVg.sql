create
    definer = root@localhost procedure sp_login_app(IN varUser varchar(45), IN varPass varchar(100))
BEGIN
  
	SELECT
	global_users.fullname_user, 
	global_permission.*, 
	global_users.user_user, 
	global_users.picture_user, 
	global_users.mail_user
FROM
	global_users
	INNER JOIN
	global_permission
	ON 
		global_users.id_permission = global_permission.id_permission
		WHERE user_user = varUser and password_user = sha1(varPass);
END;

