create
    definer = root@localhost procedure sp_login_app(IN varUser varchar(45), IN varPass varchar(100))
BEGIN
	
    select * from global_users where user_user = varUser and password_user = sha1(varPass);
    
END;

